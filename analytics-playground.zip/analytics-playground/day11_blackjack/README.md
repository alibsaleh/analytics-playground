# Day 11 — Blackjack (Stub)

**What it is:** Project skeleton only. You add the game logic (no spoilers).

## Run
```bash
python blackjack.py
```

## Tips
- Keep functions pure; return values, print in `main()`.
- Handle multiple Aces by adjusting 11→1 until total ≤ 21.
- Dealer hits until 17+ (you choose soft 17 rule).
